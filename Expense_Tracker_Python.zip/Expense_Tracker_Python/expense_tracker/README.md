# SpendWise - Django Expense Tracker

SpendWise is a modern and responsive expense tracker web app built with Django. It helps users track daily, weekly, and monthly expenses with beautiful visualizations and budget planning.

---

## Features

- User authentication (Signup/Login)
- Add, edit, and delete expenses
- Filter & sort expenses by date, category, or amount
- Monthly budget tracking
- Weekly & category-wise charts (Matplotlib)
- Responsive and clean dashboard UI
- Secure form handling with CSRF protection

---

## 📸 Screenshots

### Dashboard View
![Dashboard](screenshots/dashboard.png)

### Add Expense Page
![Add Expense](screenshots/add_expense.png)

### Edit Expense Page
![Edit Expense](screenshots/edit_expense.png)

### Weekly & Category Charts
![Charts](screenshots/charts.png)

### Login Page
![Login Page](screenshots/login.png)

---

## 🛠️ Tech Stack

- Django (Python)
- SQLite (default)
- HTML/CSS (custom responsive UI)
- Matplotlib for generating charts

---

## 🚀 How to Run Locally

1. Clone the repository:
   ```bash
   git clone https://github.com/Vaibhavgupta99/expense-tracker.git
   cd expense-tracker
